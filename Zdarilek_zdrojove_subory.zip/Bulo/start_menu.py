from tkinter import messagebox
from main import *

ws = Tk()
ws.title('start menu')
ws.resizable(False,False)

width_start_menu = 600
height_start_menu = 300

canvas = Canvas(ws, width=width_start_menu, height=height_start_menu)
canvas.pack()

# loading images from file
bg_img = PhotoImage(file='images/bk1.png')
big_game_img = PhotoImage(file='images/big.png')
medium_game_img = PhotoImage(file='images/medium.png')
small_game_img = PhotoImage(file='images/small.png')
info_img = PhotoImage(file='images/info2.png')
x_img = PhotoImage(file='images/x2.png')

# background and button settings
background = Label(canvas, image=bg_img)
background.place(x=0,y=0, relwidth=1, relheight=1)

button1 = tkinter.Button(canvas, image=small_game_img, command=lambda: start_game('small'), borderwidth=0)
button1.place(x=50, y=70)

button2 = tkinter.Button(canvas, image=medium_game_img, command=lambda: start_game('medium'), borderwidth=0)
button2.place(x=225, y=70)

button3 = tkinter.Button(canvas, image=big_game_img, command=lambda: start_game('big'), borderwidth=0)
button3.place(x=400, y=70)

button4 = tkinter.Button(canvas, image=info_img, command=lambda: instructions(), borderwidth=0)
button4.place(x=100, y=200)

button5 = tkinter.Button(canvas, image=x_img, command=lambda: close_window(), borderwidth=0)
button5.place(x=440, y=200)


def start_game(game_type):  # destroy all elements in canvas and start game
    button1.destroy()
    button2.destroy()
    button3.destroy()
    button4.destroy()
    button5.destroy()
    background.destroy()
    playing_field(ws, canvas, game_type)


def instructions():  # open messagebox with tutorial
    messagebox.showinfo("Help", "Players take turns in turns. The player removes any number of stones in each turn. However, they must all be "
                                 "part of one row or column and must be adjacent to each other. \n\nThe first and third stones in a row cannot be removed when the second stone has already been removed."
                                  "\n\nThe player who removes the last stone from the board loses.")


def close_window():  # close window
    ws.destroy()


ws.mainloop()
