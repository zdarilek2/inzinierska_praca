from tkinter import messagebox
from game import *

ws = Tk()
ws.title('start menu')
ws.resizable(False, False)
ws.iconbitmap("images/pirate_flag.ico")

width_start_menu = 600
height_start_menu = 300

canvas = Canvas(ws, width=width_start_menu, height=height_start_menu)
canvas.pack()

# loading images from file

bg_img = PhotoImage(file='images/main_desk.png')
sicilian_img = PhotoImage(file='images/button_sicilian_1.png')
pirate_img = PhotoImage(file='images/Button_pirate_1.png')

info_img = PhotoImage(file='images/info2.png')

button1 = tkinter.Button(canvas, image=sicilian_img, command=lambda: start_game('sicilian'), borderwidth=0)
button1.place(x=width_start_menu/2 - 150, y=70, anchor='center')

button2 = tkinter.Button(canvas, image=pirate_img, command=lambda: start_game('pirate'), borderwidth=0)
button2.place(x=width_start_menu/2 + 150, y=70, anchor='center')

button4 = tkinter.Button(canvas, image=info_img, command=lambda: instructions(), borderwidth=0)
button4.place(x=width_start_menu/2, y=200, anchor='center')



def start_game(game_type):  # destroy all elements in canvas and start game
    button1.destroy()
    button2.destroy()
    button4.destroy()
    playing_field(ws, canvas, game_type)


def instructions():  # open messagebox with tutorial
    messagebox.showinfo("Help", "The pirate puts poison in one of the cups. So either to your own or to the Sicilian Cup. "
                                 "The opponent does not know where the poison is and at the same time chooses a cup from which to drink.  \nHe can take either his cup or the other player's cup. The second cup will probably be drunk by a pirate."
                                  "\n\nEnd of the game: The game ends with one of the players drinking a poison cup. The player who drinks the poison lost. ")


def close_window():  # close window
    ws.destroy()


ws.mainloop()



