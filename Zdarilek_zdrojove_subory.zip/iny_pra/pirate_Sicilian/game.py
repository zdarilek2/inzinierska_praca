import tkinter
from tkinter import *
from numpy import random


# initialization of variables
choose_option = None
option_pc = None
role = None


def playing_field(tk, canvas_out, game_type_out):  # create playing field / create buttons, background...
    global game_type, canvas, player_img, player_btn, max_num, cup_pirate, cup_sicilian, background, sic_cup_l, role, pir_cup_l, button0, button1,banner1, banner2, info_btn, info_img,analysis
    count = 0

    ws = init_canvas(game_type_out,canvas_out,tk)
    banner1 = PhotoImage(file='images/sicilian win.png')
    banner2 = PhotoImage(file='images/pirate win.png')
    bg_img = PhotoImage(file='images/main_desk.png')
    sicilian_img = PhotoImage(file='images/pirate_cup_1.png')
    pirate_img = PhotoImage(file='images/pirate_cup_1.png')
    role = game_type_out
    info_img = PhotoImage(file='images/info2.png')
    if(game_type_out == 'sicilian'):
        cup_pirate = tkinter.Button(canvas, image=pirate_img, command= lambda: click('pirate'), borderwidth=2)
        cup_pirate.place(x=600, y=250, anchor='center')
        cup_sicilian = tkinter.Button(canvas, image=sicilian_img, command= lambda: click('sicilian'), borderwidth=2)
        cup_sicilian.place(x=200, y=250, anchor='center')
        bg_img = PhotoImage(file='images/pirate_choose_1.png')
        background = Label(canvas, image=bg_img,borderwidth=0)
        background.place(x=400, y=50, anchor='center')

    if(game_type_out == 'pirate'):
        cup_pirate = tkinter.Button(canvas, image=pirate_img, command= lambda: click('pirate'), borderwidth=2)
        cup_pirate.place(x=600, y=250, anchor='center')
        cup_sicilian = tkinter.Button(canvas, image=sicilian_img, command= lambda: click('sicilian'), borderwidth=2)
        cup_sicilian.place(x=200, y=250, anchor='center')
        bg_img = PhotoImage(file='images/sicilian_choose_1.png')
        background = Label(canvas, image=bg_img,borderwidth=0)
        background.place(x=400, y=50, anchor='center')
    pir_pohar = PhotoImage(file='images/button_sicilian_2.png')
    pir_cup_l = Label(canvas, image=pir_pohar,borderwidth=0)
    pir_cup_l.place(x=200, y=350, anchor='center')

    sic_pohar = PhotoImage(file='images/Button_pirate_2.png')
    sic_cup_l = Label(canvas, image=sic_pohar,borderwidth=0)
    sic_cup_l.place(x=600, y=350, anchor='center')

    button0 = tkinter.Button(canvas, text="Drinking", font=("Comic Sans MS", 31), command=lambda: destroy_all(),
                             borderwidth=0, bg="white")
    button1 = tkinter.Button(canvas, text="Click here to show result", font=("Comic Sans MS", 12),
                             command=lambda: destroy_all(), borderwidth=0, bg="white")

    analysis = PhotoImage(file='images/analyza.png')

    ws.mainloop()


def init_canvas(game_type_out,canvas_out, tk):  # init canvas, tk and game_type variable
    pass
    global game_type, canvas, ws
    game_type = game_type_out
    canvas = canvas_out
    canvas.configure(background='white')
    ws = tk
    ws.title('You are : ' + game_type_out)
    canvas.config(width=800, height=400)
    return ws


def click(v):  # check clicked button / if pressed correctly it will delete
    global choose_option
    choose_option = v
    cup_sicilian["state"] = "disabled"
    cup_pirate["state"] = "disabled"
    drinking_text()


def destroy_all():  #remove buttons and show results
    global cup_sicilian, cup_pirate,background, pir_cup_l, sic_cup_l, button0, button1

    background.destroy()
    cup_sicilian.destroy()
    cup_pirate.destroy()
    pir_cup_l.destroy()
    sic_cup_l.destroy()
    button0.destroy()
    button1.destroy()
    show_result()


def drinking_text():  # show drinking text
    global canvas, user_password, ws, button0, button1

    button0.place(x=400,y=175, anchor='center')
    button1.place(x=400, y=225, anchor='center')


def show_result():
    global choose_option, banner1, banner2, role, option_pc, info_btn, info_img

    random1()
    if option_pc == choose_option:
        if role == 'sicilian':
            background = Label(canvas, image=banner2)
        else:
            background = Label(canvas, image=banner2)
    else:
        if role == 'sicilian':
            background = Label(canvas, image=banner1)
        else:
            background = Label(canvas, image=banner1)
    background.place(x=400, y=200, anchor='center')
    info_btn = tkinter.Button(canvas, image=info_img, command=lambda: show_analysis(info_btn,background), borderwidth=0)
    info_btn.place(x=400, y=370,anchor='center')


def random1():   # give random option (sicialian or pirate)
    global option_pc
    c = random.randint(2)
    if c == 0:
        option_pc = 'sicilian'
    else:
        option_pc = 'pirate'


def show_analysis(info_btn, background):  # show image with analysis
    global analysis
    info_btn.destroy()
    background.destroy()
    nieco = Label(canvas, image=analysis,borderwidth=0)
    nieco.place(x=400, y=200, anchor='center')
